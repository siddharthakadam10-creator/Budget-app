# BudgetPilot v4
Personal finance Android app focused on simple Google Pay statement import.

## User flow
Google Pay → Transaction history → Get Statement → Save PDF → BudgetPilot → Import Google Pay statement.

## v4 UI
- Cleaner finance-app style dashboard
- Monthly summary cards
- Category spending section
- Prominent Google Pay import button
- Searchable transactions
- Monthly budget
- CSV export
- Duplicate protection
- Automatic bank/UPI SMS capture
- Offline local storage

## Build
Use a cloud Android build service with this project. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

Do not upload personal Google Pay statements to public repositories.
