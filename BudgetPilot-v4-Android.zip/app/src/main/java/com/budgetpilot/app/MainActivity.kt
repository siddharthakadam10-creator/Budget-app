package com.budgetpilot.app

import android.Manifest
import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.InputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

data class Tx(val id: Long, val amount: Double, val category: String, val source: String, val note: String, val date: Long)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("budgetpilot", MODE_PRIVATE) }
    private val nf = NumberFormat.getCurrencyInstance(Locale("en","IN"))
    private val categories = listOf("Food","Travel","Shopping","Bills","Entertainment","Health","Groceries","Other")
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        PDFBoxResourceLoader.init(getApplicationContext())
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 20)
        buildShell()
        showDashboard()
    }

    private fun buildShell() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE)}
        val header=TextView(this).apply{
            text="BudgetPilot"; textSize=30f; setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(18,65,110)); setPadding(24,28,24,18)
        }
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(20,8,20,12)}
        val scroll=ScrollView(this).apply{addView(content)}
        nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(8,8,8,12)}
        listOf("Dashboard","Transactions","Budget","More").forEach { label ->
            nav.addView(Button(this).apply{ text=label; setOnClickListener{
                when(label){"Dashboard"->showDashboard();"Transactions"->showTransactions();"Budget"->showBudget();else->showMore()}
            }}, LinearLayout.LayoutParams(0,60,1f))
        }
        root.addView(header);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));root.addView(nav)
        setContentView(root)
    }

    private fun txs(): MutableList<Tx> = prefs.getStringSet("transactions", emptySet())!!.mapNotNull {
        val p=it.split("|",limit=6); if(p.size<6)null else Tx(p[0].toLongOrNull()?:0,p[1].toDoubleOrNull()?:0,p[2],p[3],p[4],p[5].toLongOrNull()?:0)
    }.toMutableList()

    private fun saveTx(t:Tx){
        val s=txs().filterNot{it.id==t.id}.map{enc(it)}.toMutableSet();s.add(enc(t));prefs.edit().putStringSet("transactions",s).apply()
    }
    private fun enc(t:Tx)="${t.id}|${t.amount}|${t.category}|${t.source}|${t.note}|${t.date}"

    private fun money(x:Double)=nf.format(x)
    private fun card(title:String,value:String,sub:String=""):TextView{
        return TextView(this).apply{text="$title\n$value\n$sub";textSize=18f;setTextColor(Color.rgb(25,55,85));setPadding(20,20,20,20);setBackgroundColor(Color.rgb(239,246,252))}
    }
    private fun clear(){content.removeAllViews()}

    private fun showDashboard(){
        clear()
        val now=Calendar.getInstance();val month=now.get(Calendar.MONTH);val year=now.get(Calendar.YEAR)
        val current=txs().filter{val c=Calendar.getInstance().apply{timeInMillis=it.date};c.get(Calendar.MONTH)==month&&c.get(Calendar.YEAR)==year}
        val total=current.sumOf{it.amount};val budget=prefs.getFloat("monthly_budget",50000f).toDouble()
        content.addView(TextView(this).apply{text="Good morning 👋";textSize=16f;setTextColor(Color.DKGRAY)})
        content.addView(TextView(this).apply{
            text=SimpleDateFormat("MMMM yyyy",Locale.ENGLISH).format(Date());textSize=24f
            setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,4,0,16)
        })
        content.addView(card("💸  Total spending",money(total),"Monthly budget  •  ${money(budget)}"))
        content.addView(card("💰  Remaining",money(max(0.0,budget-total)),
            "${((total/budget)*100).coerceAtMost(999.0).toInt()}% of budget used"))
        val cat=current.groupBy{it.category}.mapValues{it.value.sumOf{t->t.amount}}.toList().sortedByDescending{it.second}
        content.addView(TextView(this).apply{
            text="\nWhere your money goes";textSize=20f
            setTypeface(null,android.graphics.Typeface.BOLD)
        })
        cat.take(8).forEach{(c,a)->content.addView(TextView(this).apply{text="$c   ${money(a)}";textSize=17f;setPadding(8,10,8,10)})}
        val import=Button(this).apply{
            text="📄  Import Google Pay statement"; setOnClickListener{pickStatement()}
        }
        content.addView(import)
        val add=Button(this).apply{text="＋  Add expense manually";setOnClickListener{addExpense()}}
        content.addView(add)
    }

    private fun showTransactions(){
        clear()
        val search=EditText(this).apply{hint="Search transactions";setSingleLine()}
        content.addView(search)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(list)
        fun render(){
            list.removeAllViews();val q=search.text.toString().lowercase()
            txs().sortedByDescending{it.date}.filter{q.isBlank()||it.note.lowercase().contains(q)||it.category.lowercase().contains(q)}.forEach{t->
                list.addView(TextView(this).apply{
                    text="${money(t.amount)}  •  ${t.category}\n${t.note}\n${SimpleDateFormat("dd MMM yyyy",Locale.ENGLISH).format(Date(t.date))}"
                    textSize=16f;setPadding(8,14,8,14)
                    setOnLongClickListener{confirmDelete(t);true}
                })
            }
        }
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        render()
        content.addView(Button(this).apply{text="＋ Add expense";setOnClickListener{addExpense()}})
    }

    private fun showBudget(){
        clear()
        val input=EditText(this).apply{hint="Monthly budget in ₹";setText(prefs.getFloat("monthly_budget",50000f).toString());inputType=2}
        content.addView(TextView(this).apply{text="Monthly budget";textSize=22f})
        content.addView(input)
        content.addView(Button(this).apply{text="Save budget";setOnClickListener{
            input.text.toString().toFloatOrNull()?.let{prefs.edit().putFloat("monthly_budget",it).apply();showBudget()}
        }})
        val total=txs().sumOf{it.amount};content.addView(card("All-time tracked spending",money(total)))
    }

    private fun showMore(){
        clear()
        content.addView(TextView(this).apply{text="Import & Tools";textSize=24f})
        content.addView(Button(this).apply{text="📄 Import Google Pay statement (PDF)";setOnClickListener{pickStatement()}})
        content.addView(TextView(this).apply{
            text="\nGoogle Pay: See transaction history → ⋮ → Get Statement → choose period → save/share the PDF. Then import it here."
            textSize=15f
        })
        content.addView(Button(this).apply{text="Export transactions to CSV";setOnClickListener{exportCsv()}})
        content.addView(Button(this).apply{text="Clear all local transactions";setOnClickListener{
            AlertDialog.Builder(this).setTitle("Clear data?").setMessage("This deletes all transactions stored on this device.")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->prefs.edit().remove("transactions").apply();showDashboard()}.show()
        }})
    }

    private fun pickStatement(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE);type="application/pdf"
        }
        startActivityForResult(i,501)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==501 && resultCode==RESULT_OK){
            data?.data?.let{ importGooglePayPdf(it) }
        }
    }

    private fun importGooglePayPdf(uri:Uri){
        try{
            val text=contentResolver.openInputStream(uri)?.use{ input->
                PDDocument.load(input).use{ PDFTextStripper().getText(it) }
            } ?: ""
            val imported=parseGooglePayStatement(text)
            if(imported.isEmpty()){
                AlertDialog.Builder(this).setTitle("No transactions found")
                    .setMessage("I couldn't recognize expense rows in this statement. You can still add expenses manually.")
                    .setPositiveButton("OK",null).show()
                return
            }
            val existing=txs().map{key(it)}.toMutableSet()
            var added=0
            imported.forEach{t->if(existing.add(key(t))){saveTx(t);added++}}
            AlertDialog.Builder(this).setTitle("Statement imported")
                .setMessage("$added new expense transactions imported. Duplicate transactions were skipped.")
                .setPositiveButton("View dashboard"){_,_->showDashboard()}.show()
        }catch(e:Exception){
            AlertDialog.Builder(this).setTitle("Import failed")
                .setMessage("The PDF could not be read. Try downloading the Google Pay e-statement again.")
                .setPositiveButton("OK",null).show()
        }
    }

    private fun key(t:Tx)="%.2f|%s|%s|%s".format(Locale.US,t.amount,t.note,t.date/86400000,t.source)

    private fun parseGooglePayStatement(text:String):List<Tx>{
        val out=mutableListOf<Tx>()
        // Google Pay statement formats can change. We intentionally use tolerant
        // line parsing and only import rows that clearly contain a debit amount.
        val dateRx=Regex("""(?i)\\b(\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}|\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{4})\\b""")
        val amountRx=Regex("""(?i)(?:₹|Rs\\.?|INR)\\s*([0-9][0-9,]*(?:\\.\\d{1,2})?)""")
        val debitWords=Regex("""(?i)\\b(paid|payment|sent|debit|debited|spent|purchase|transfer)\\b""")
        val creditWords=Regex("""(?i)\\b(received|credit|credited|refund|cashback|reversal)\\b""")
        text.lines().forEachIndexed{idx,line->
            val dm=dateRx.find(line); val am=amountRx.find(line)
            if(dm!=null && am!=null && debitWords.containsMatchIn(line) && !creditWords.containsMatchIn(line)){
                val amount=am.groupValues[1].replace(",","").toDoubleOrNull()?:return@forEachIndexed
                val date=parseDate(dm.groupValues[1])?:System.currentTimeMillis()
                val note=line.replace(Regex("""\\s+""")," ").trim()
                val cat=guessCategory(note)
                out.add(Tx(System.currentTimeMillis()+idx,amount,cat,"Google Pay PDF",note,date))
            }
        }
        return out
    }

    private fun parseDate(x:String):Long?{
        val formats=listOf("dd/MM/yyyy","dd-MM-yyyy","d/M/yyyy","d-M-yyyy","dd MMM yyyy","d MMM yyyy")
        for(f in formats) try{return SimpleDateFormat(f,Locale.ENGLISH).parse(x)?.time}catch(_:Exception){}
        return null
    }

    private fun guessCategory(s:String):String{
        val x=s.lowercase()
        return when{
            listOf("swiggy","zomato","restaurant","food","cafe","hotel").any{x.contains(it)}->"Food"
            listOf("uber","ola","rapido","metro","petrol","fuel","parking").any{x.contains(it)}->"Travel"
            listOf("amazon","flipkart","myntra","mall","shopping").any{x.contains(it)}->"Shopping"
            listOf("electricity","recharge","bill","water","gas","broadband").any{x.contains(it)}->"Bills"
            listOf("movie","netflix","spotify","prime","entertainment").any{x.contains(it)}->"Entertainment"
            listOf("pharmacy","hospital","medical","clinic").any{x.contains(it)}->"Health"
            listOf("grocery","supermarket","dmart").any{x.contains(it)}->"Groceries"
            else->"Other"
        }
    }

    private fun addExpense(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val amount=EditText(this).apply{hint="Amount ₹";inputType=2}
        val note=EditText(this).apply{hint="Description / merchant"}
        val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,categories)
        box.addView(amount);box.addView(note);box.addView(spinner)
        AlertDialog.Builder(this).setTitle("Add expense").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
            val a=amount.text.toString().toDoubleOrNull()?:return@setPositiveButton
            saveTx(Tx(System.currentTimeMillis(),a,spinner.selectedItem.toString(),"Manual",note.text.toString(),System.currentTimeMillis()));showDashboard()
        }.show()
    }

    private fun confirmDelete(t:Tx){AlertDialog.Builder(this).setTitle("Delete transaction?").setPositiveButton("Delete"){_,_->
        prefs.edit().putStringSet("transactions",txs().filterNot{it.id==t.id}.map{enc(it)}.toSet()).apply();showTransactions()
    }.setNegativeButton("Cancel",null).show()}

    private fun exportCsv(){
        val sb=StringBuilder("Date,Amount,Category,Source,Note\n")
        txs().sortedBy{it.date}.forEach{t->sb.append("${t.date},${t.amount},${t.category},${t.source},\"${t.note.replace("\"","\"\"")}\"\n")}
        val i=Intent(Intent.ACTION_SEND).apply{type="text/csv";putExtra(Intent.EXTRA_TEXT,sb.toString());putExtra(Intent.EXTRA_SUBJECT,"BudgetPilot transactions")}
        startActivity(Intent.createChooser(i,"Export CSV"))
    }
}
