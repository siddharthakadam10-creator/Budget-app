package com.budgetpilot.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver: BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        if(intent.action!=Telephony.Sms.Intents.SMS_RECEIVED_ACTION)return
        val p=context.getSharedPreferences("budgetpilot",Context.MODE_PRIVATE)
        val set=p.getStringSet("transactions",emptySet())!!.toMutableSet()
        for(s in Telephony.Sms.Intents.getMessagesFromIntent(intent)){
            val body=s.messageBody?:continue
            val r=Regex("(?i)(?:Rs\\.?|INR)\\s*([0-9,]+(?:\\.\\d{1,2})?).{0,100}(?:debited|paid|sent)")
            val m=r.find(body)?:continue
            val amount=m.groupValues[1].replace(",","").toDoubleOrNull()?:continue
            val lower=body.lowercase()
            val cat=when{
                listOf("swiggy","zomato","restaurant","food","cafe").any{lower.contains(it)}->"Food"
                listOf("uber","ola","rapido","metro","fuel","petrol").any{lower.contains(it)}->"Travel"
                listOf("amazon","flipkart","myntra","shopping").any{lower.contains(it)}->"Shopping"
                listOf("electricity","recharge","bill","water","gas").any{lower.contains(it)}->"Bills"
                else->"Other"
            }
            set.add("${System.currentTimeMillis()}|$amount|$cat|SMS|${body.replace("|"," ")}|${System.currentTimeMillis()}")
        }
        p.edit().putStringSet("transactions",set).apply()
    }
}